Run a development web server with Uvicorn using this line:
" uvicorn shortener_app.main:app --reload "

after running the code, checkout "http://127.0.0.1:8000/docs"